﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UI1
{
    class BingSearchProvider
    {
        internal void SearchAsync(SearchRequest request)
        {
            throw new NotImplementedException();
        }

        public EventHandler<SearchCompletedEventArgs> SearchCompleted { get; set; }
    }
}
