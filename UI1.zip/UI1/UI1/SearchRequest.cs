﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UI1
{
    class SearchRequest
    {
        public System.Globalization.CultureInfo Culture { get; set; }

        public string Query { get; set; }
    }
}
