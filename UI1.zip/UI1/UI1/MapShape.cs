﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UI1
{
    class MapShape
    {
        public System.Windows.Media.SolidColorBrush Stroke { get; set; }

        public int StrokeThickness { get; set; }
    }
}
